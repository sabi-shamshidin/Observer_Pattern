package com.company;

import java.util.ArrayList;
import java.util.List;

public class Netflix extends Observable {

    private List<String> films = new ArrayList<>();
    private List<Observer> observers = new ArrayList<>();

    public void addEpisode(String films) {
        this.films.add(films);
        notifyAllObservers();
    }

    @Override
    public void register(Observer observer) {
        this.observers.add(observer);
    }

    @Override
    public void unregister(Observer observer) {
        this.observers.remove(observer);
    }

    @Override
    public void notifyAllObservers() {
        for (Observer observer: observers) {
            observer.update(this.films);
        }
    }
}
