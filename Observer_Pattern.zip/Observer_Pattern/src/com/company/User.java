package com.company;

import java.util.List;

public class User implements Observer {
    private String login;
    public User(String login) {
        this.login = login;
    }

    @Override
    public void update(List<String> episodes) {
        System.out.println("Hi " + login + "! The new episodes of Game of Thrones are out! Enjoy watching :)\n" + episodes + '\n');
    }
}
