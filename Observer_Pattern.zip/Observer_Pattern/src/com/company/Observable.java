package com.company;

public abstract class Observable {
    abstract void register(Observer observer);
    abstract void unregister(Observer observer);
    abstract void notifyAllObservers();
}
