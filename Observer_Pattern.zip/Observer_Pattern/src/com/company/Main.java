package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Netflix got = new Netflix();

        System.out.println("Hello! What is your name?");
        String name = scan.nextLine();

        got.addEpisode("Episode 12");
        got.addEpisode("Episode 13");
        
        User user1 = new User(name);
        got.register(user1);

        got.addEpisode("Episode 14");
    }
}
